
app.controller("filmList",function ($scope,filmService) {
    function callback(obj) {
        $scope.films=obj;
        $scope.showinfo=function (film){
            butt=film;

            document.getElementById("title").value=film.title;
            document.getElementById("ReleaseYear").value=film.releaseYear;
           
            document.getElementById("Rating").value=film.rating;
            document.getElementById("Description").value=film.description;
            document.getElementById("Length").value=film.length;
            document.getElementById("Language").value=film.language;
            var actors=film.actors;
            console.log(actors);
        }
        
    }
    filmService(callback);
    
})
